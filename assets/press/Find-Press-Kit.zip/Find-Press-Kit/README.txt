
Hey! I'm Andrew, the developer of this app. Thank you for checking out Find, I'd love to get in touch!

⸻ Description ⸻

Find is an app to find text in real life. Look for text anywhere, whether that’s in screenshots, books, or even nutrition labels — all in real time. Search your entire photo library in a split second and organize it with stars. Find in real-time using the camera and speed through forms and worksheets. Create lists of allergies or dietary restrictions and find unwanted ingredients instantly. Find is faster than the human eye.
 

Find was designed with privacy in mind, so all processes happen offline and nothing ever leaves your phone. There are no servers, no data collection, no analytics, and no internet connection is required.


Find is a free app. It has no ads, subscriptions, or in-app purchases.

⸻ Features ⸻

- Photos. The fastest way to find what you're looking for.
  - Get results instantly as you type in the search bar.
  - Organize photos with stars.
  - Search in starred photos, screenshots, or all photos.
  - Superfast scanning (~10 photos per second on iPhone 13).
  - Ignore photos that you don't want Find to scan.
  - Everything runs 100% offline and nothing ever leaves your device.
- Camera. Scan through books and worksheets like they're nothing.
  - Look for text in real-time.
  - Find words in books, forms, and worksheets.
  - Read nutrition labels automatically.
  - Supports zoom, panning, and flash.
  - Supports landscape mode.
- Lists. Group words together and search for them all at the same time.
  - Works great for allergies and other dietary restrictions.
  - Supports sharing and importing lists via URL.
  - Use Lists anywhere in the app - Photos, Camera, and Settings all work.
- Search bar. I call it the Findbar™.
  - Add multiple search bars — as many as you would like.
  - Override highlight colors on-the-fly.
- Settings. Customize extensively.
  - Customize the default tab.
  - Advanced finding options.
  - Advanced highlight options.
  - Change the size of photos.
  - Optimize finding with the camera.
  - Change how lists are sorted.
- Supports VoiceOver and haptics.

⸻ Helpful Links ⸻

Find Website: https://getfind.app
Find App Store URL: https://apps.apple.com/app/id1506500202
Find Twitter: https://twitter.com/getfindapp
Developer Twitter: https://twitter.com/aheze0
Developer Reddit: https://www.reddit.com/user/aheze
Developer Email: aheze@getfind.app

